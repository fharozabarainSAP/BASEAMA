/* Complete Ecosystemplus Assessment Platform with In-Question Targets + Guidance */
(async () => {
  const root = document.getElementById('app');
  let currentUser = null;
  let currentSession = null;
  let db = null;

  /* ============================================
     DATABASE INITIALIZATION
  ============================================ */
  const initDB = () => {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('SAPAssessmentDB', 1);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        db = request.result;
        resolve(db);
      };

      request.onupgradeneeded = (event) => {
        db = event.target.result;

        if (!db.objectStoreNames.contains('sessions')) {
          const store = db.createObjectStore('sessions', { keyPath: 'id', autoIncrement: true });
          store.createIndex('company', 'company', { unique: false });
          store.createIndex('timestamp', 'timestamp', { unique: false });
        }
      };
    });
  };

  /* ============================================
     DATABASE OPERATIONS
  ============================================ */
  const saveSession = async (sessionData) => {
    return new Promise((resolve) => {
      const tx = db.transaction(['sessions'], 'readwrite');
      const request = tx.objectStore('sessions').add(sessionData);
      request.onsuccess = () => resolve(request.result);
    });
  };

  const exportToCSV = async () => {
    return new Promise((resolve) => {
      const tx = db.transaction(['sessions'], 'readonly');
      const request = tx.objectStore('sessions').getAll();
      request.onsuccess = () => {
        const sessions = request.result;
        let csv = 'Company,Participant_Name,Role,Email,Domain,Score,Target,Gap,Timestamp\n';

        sessions.forEach(s => {
          s.results.forEach(r => {
            csv += `"${s.company}","${s.participantName}","${s.participantRole}","${s.participantEmail}","${r.name}",${r.score},${r.target},${r.gap},"${s.timestamp}"\n`;
          });
        });

        resolve(csv);
      };
    });
  };

  const exportToSQL = async () => {
    return new Promise((resolve) => {
      const tx = db.transaction(['sessions'], 'readonly');
      const request = tx.objectStore('sessions').getAll();
      request.onsuccess = () => {
        const sessions = request.result;

        let sql = `-- SAP Assessment Database Export\n`;
        sql += `-- Generated: ${new Date().toISOString()}\n\n`;
        sql += `CREATE TABLE IF NOT EXISTS assessment_sessions (\n`;
        sql += `  id INTEGER PRIMARY KEY,\n`;
        sql += `  company TEXT,\n`;
        sql += `  participant_name TEXT,\n`;
        sql += `  participant_role TEXT,\n`;
        sql += `  participant_email TEXT,\n`;
        sql += `  overall_average REAL,\n`;
        sql += `  weighted_average REAL,\n`;
        sql += `  critical_gaps INTEGER,\n`;
        sql += `  timestamp TEXT\n`;
        sql += `);\n\n`;

        sql += `CREATE TABLE IF NOT EXISTS assessment_results (\n`;
        sql += `  id INTEGER PRIMARY KEY,\n`;
        sql += `  session_id INTEGER,\n`;
        sql += `  domain_name TEXT,\n`;
        sql += `  score INTEGER,\n`;
        sql += `  target INTEGER,\n`;
        sql += `  gap REAL,\n`;
        sql += `  priority TEXT\n`;
        sql += `);\n\n`;

        sessions.forEach((s, idx) => {
          sql += `INSERT INTO assessment_sessions VALUES (${idx + 1}, '${s.company}', '${s.participantName}', '${s.participantRole}', '${s.participantEmail}', ${s.overallAverage}, ${s.weightedAverage}, ${s.criticalGaps}, '${s.timestamp}');\n`;

          s.results.forEach(r => {
            sql += `INSERT INTO assessment_results VALUES (NULL, ${idx + 1}, '${r.name}', ${r.score}, ${r.target}, ${r.gap}, '${r.priority}');\n`;
          });
        });

        resolve(sql);
      };
    });
  };

  /* ============================================
     ASSESSMENT DATA CONFIGURATION
     (Updated with Excel domain names)
  ============================================ */
  const domains = [
    { ID: 1, name: 'Practice Governance & Compliance', target: null, weight: 1.0 },
    { ID: 2, name: 'Strategic Positioning and EA Relevance', target: null, weight: 1.0 },
    { ID: 3, name: 'EA Practice Operational Maturity', target: null, weight: 1.0 },
    { ID: 4, name: 'EA Platform Enablement and Knowledge Management', target: null, weight: 1.1 },
    { ID: 5, name: 'Data Architecture Capability', target: null, weight: 1.0 },
    { ID: 6, name: 'Technology and Development Practices', target: null, weight: 1.0 },
    { ID: 7, name: 'Stakeholder and Cross-Functional Collaboration', target: null, weight: 1.0 }
  ];

  const MATRIX = {
    1: {
      question: 'Is there formal ownership and governance of EA delivery?',
      expl: [
        'No defined ownership or governance for EA service delivery.',
        'EA services are informally provided; governance varies by engagement.',
        'Basic governance structures exist; limited consistency.',
        'Formalised EA governance across engagements; roles defined.',
        'Governance embedded into delivery frameworks; aligned with SAP methodologies.',
        'EA governance proactively steers customer transformations at scale.'
      ],
      recommendations: {
        0: 'Establish basic EA governance framework and assign clear ownership roles.',
        1: 'Formalize EA governance processes and create consistent delivery standards.',
        2: 'Enhance governance with regular reviews and stakeholder alignment.',
        3: 'Integrate governance with enterprise delivery methodologies.',
        4: 'Optimize governance for proactive transformation leadership.',
        5: 'Continue excellence and share best practices across organization.'
      }
    },
    2: {
      question: 'Is EA positioned as a strategic service offering?',
      expl: [
        'EA services seen as technical add-on, not strategic offering.',
        'Initial recognition of EA; loosely connected to customer strategies.',
        'EA linked to IT roadmaps; emerging strategic relevance.',
        'EA positioned as critical enabler of business transformation.',
        'EA actively shapes customer innovation, Clean Core & modular architectures.',
        'EA is a strategic differentiator in partner market positioning.'
      ],
      recommendations: {
        0: 'Develop strategic positioning framework and value proposition for EA services.',
        1: 'Strengthen connection between EA services and customer business outcomes.',
        2: 'Expand EA influence beyond IT into business transformation initiatives.',
        3: 'Leverage EA as key differentiator in competitive positioning.',
        4: 'Lead market innovation through advanced EA capabilities.',
        5: 'Maintain market leadership and explore new strategic opportunities.'
      }
    },
    3: {
      question: 'Are EA services standardised and repeatable?',
      expl: [
        'EA delivery is ad-hoc and varies by project or architect.',
        'Some EA methods exist; not standardised across engagements.',
        'Templates & reusable assets starting to be used.',
        'Standardised EA portfolio consistently used across engagements.',
        'Industrialised EA with QA & knowledge reuse.',
        'Scalable, repeatable EA embedded across regions & industries.'
      ],
      recommendations: {
        0: 'Develop standardized EA methodologies and reusable templates.',
        1: 'Create comprehensive EA asset library and ensure consistent usage.',
        2: 'Implement quality assurance processes and knowledge management.',
        3: 'Optimize standardization for efficiency and scale.',
        4: 'Enhance industrialization with advanced automation and AI.',
        5: 'Continue innovation in standardization and share best practices.'
      }
    },
    4: {
      question: 'Are tools and knowledge assets used consistently?',
      expl: [
        'No formal EA tools or knowledge repositories.',
        'Tools/templates exist but ad-hoc usage.',
        'Initial EA toolsets & knowledge assets developed.',
        'Tools/templates systematically applied across engagements.',
        'Integrated EA platforms enable efficient delivery & reuse.',
        'EA platforms fully embedded with continuous knowledge evolution.'
      ],
      recommendations: {
        0: 'Implement foundational EA tools and establish knowledge repositories.',
        1: 'Standardize tool usage and create systematic knowledge capture processes.',
        2: 'Integrate tools into delivery workflows and enhance knowledge sharing.',
        3: 'Optimize tool utilization and implement advanced knowledge management.',
        4: 'Leverage AI and automation for enhanced tool capabilities.',
        5: 'Lead innovation in EA tooling and knowledge management.'
      }
    },
    5: {
      question: 'Is data architecture embedded into solution design?',
      expl: [
        'Data architecture rarely considered in EA engagements.',
        'Data models/integration patterns addressed inconsistently.',
        'Emerging focus on data architecture, standards applied.',
        'Data governance & architecture embedded in solutions.',
        'Data-driven principles enable Clean Core & BTP innovation.',
        'Data-architecture excellence drives insights & outcomes.'
      ],
      recommendations: {
        0: 'Establish data architecture competency and integration standards.',
        1: 'Develop comprehensive data governance framework.',
        2: 'Enhance data architecture capabilities and Clean Core alignment.',
        3: 'Optimize data-driven solution design and BTP integration.',
        4: 'Lead data architecture innovation and advanced analytics.',
        5: 'Maintain excellence and explore emerging data technologies.'
      }
    },
    6: {
      question: 'Do EA services reflect SAP architecture principles?',
      expl: [
        'Architectures lack cloud, modularisation, DevOps alignment.',
        'Isolated cloud-native or modular practices.',
        'Increasing alignment with Clean Core, BTP, modern SAP tech.',
        'Cloud-first, API-first, modular architectures standard.',
        'EA integrates advanced tech & DevOps in every transformation.',
        'EA leads innovation & modernisation across portfolios.'
      ],
      recommendations: {
        0: 'Develop SAP-aligned architecture principles and cloud-first approach.',
        1: 'Implement comprehensive Clean Core and BTP integration.',
        2: 'Enhance modular architecture capabilities and DevOps practices.',
        3: 'Optimize advanced SAP technology integration.',
        4: 'Lead SAP innovation and modernization initiatives.',
        5: 'Continue market leadership in SAP architecture excellence.'
      }
    },
    7: {
      question: 'Is EA engaged across functions and leadership?',
      expl: [
        'Limited collaboration with business or delivery stakeholders.',
        'Initial interactions with technical stakeholders; limited business engagement.',
        'Broader collaboration emerging across business & IT.',
        'EA drives cross-functional collaboration & joint ownership.',
        'EA enables strategic alignment across functions & teams.',
        'EA trusted by C-level, influencing strategic programmes.'
      ],
      recommendations: {
        0: 'Establish cross-functional EA engagement model and stakeholder mapping.',
        1: 'Develop business relationship management and expand engagement.',
        2: 'Enhance collaboration frameworks and joint ownership models.',
        3: 'Optimize strategic alignment and influence across organization.',
        4: 'Lead strategic transformation initiatives and C-level engagement.',
        5: 'Maintain trusted advisor status and explore new influence opportunities.'
      }
    }
  };

  /* Lightweight "Need help?" guidance per domain (context & examples) */
  const GUIDANCE = {
    1: [
      'Roles: EA Lead/Owner, Steering Committee, RACI for decisions.',
      'Cadence: Quarterly governance boards, decision logs, escalation path.',
      'Artifacts: EA charter, policies, backlog, KPI dashboard.'
    ],
    2: [
      'Value: Link EA initiatives to revenue, margin, risk.',
      'Alignment: Tie to OKRs, strategy maps, investment cases.',
      'Visibility: EA in portfolio boards & transformation programs.'
    ],
    3: [
      'Method: Standard playbooks, templates, and quality gates.',
      'Reuse: Reference architectures, decision records, patterns.',
      'Scale: Training, certification, peer reviews.'
    ],
    4: [
      'Tools: LeanIX/Signavio/SAP BTP repos; Confluence/SharePoint.',
      'Practice: Golden sources, naming conventions, versioning.',
      'Enablement: Onboarding guides, office hours, FAQs.'
    ],
    5: [
      'Data: Canonical models, master data ownership, lineage.',
      'Integration: Event/API standards, semantic hubs.',
      'Governance: Data owners, data quality SLAs, catalogs.'
    ],
    6: [
      'Principles: Clean Core, API-first, extensibility on BTP.',
      'Ops: CI/CD, IaC, automated tests, observability.',
      'Modernization: Cloud adoption roadmap, strangler patterns.'
    ],
    7: [
      'Stakeholders: Business owners, delivery leads, security, finance.',
      'Working model: Joint OKRs, cross-functional ceremonies.',
      'Outcomes: Co-authored roadmaps, shared KPIs.'
    ]
  };

  const BENCHMARKS = { industry: { avg: 2.8, top25: 3.5, top10: 4.2 } };

  /* ============================================
     HELPERS
  ============================================ */
  const getPriorityLevel = (gap) => {
    if (gap >= 2) return 'high';
    if (gap >= 1) return 'medium';
    return 'low';
  };

  const showLoading = (message = 'Loading...') => {
    root.innerHTML = `
      <div class="min-h-screen flex items-center justify-center">
        <div class="text-center">
          <div class="sap-spinner mx-auto mb-4"></div>
          <p class="text-gray-600">${message}</p>
        </div>
      </div>
    `;
  };

  /* ============================================
     COMPANY & PARTICIPANT REGISTRATION
  ============================================ */
  function renderCompanySetup() {
    root.innerHTML = `
      <div class="login-container">
        <div class="login-card p-8 animate-fade-in">
          <div class="text-center mb-8">
            <div class="mb-6">
              <svg width="80" height="32" viewBox="0 0 80 32" class="mx-auto">
                <path fill="#0a6ed1" d="M0 8h16v16H0V8zm20 0h16v16H20V8zm20 0h16v16H40V8zm20 0h16v16H60V8z"/>
                <text x="40" y="28" text-anchor="middle" font-family="Arial" font-size="10" font-weight="bold" fill="#354a5f">SAP</text>
              </svg>
            </div>
            <h1 class="text-2xl font-bold text-gray-800 mb-2">Ecosystemplus Assessment Platform</h1>
            <p class="text-gray-600">Enterprise Architecture Maturity Assessment</p>
          </div>

          <form id="setupForm" class="space-y-6">
            <div class="sap-input-group">
              <input type="text" id="company" class="sap-input" placeholder=" " required>
              <label for="company" class="sap-label">Company Name</label>
            </div>

            <div>
              <label class="block text-sm font-medium mb-2 text-gray-700">Assessment Participants</label>
              <div id="participantsList" class="space-y-4"></div>
              <button type="button" onclick="addParticipant()" class="mt-3 text-sapblue text-sm hover:underline">
                + Add Participant
              </button>
            </div>

            <button type="submit" class="sap-button">
              <span id="submitText">Start Assessment</span>
              <div id="submitSpinner" class="sap-spinner ml-2 hidden"></div>
            </button>
          </form>

          <div class="mt-6 text-center text-xs text-gray-500">
            <p>© 2025 SAP SE. All rights reserved.</p>
            <p>Your data will be stored locally and can be exported</p>
          </div>
        </div>
      </div>
    `;

    // Add first participant field by default
    addParticipant();

    document.getElementById('setupForm').addEventListener('submit', handleSetup);
  }

  /* Add participant input fields */
  window.addParticipant = () => {
    const container = document.getElementById('participantsList');
    const index = container.children.length;
    const div = document.createElement('div');
    div.className = 'border rounded p-4 bg-gray-50';
    div.innerHTML = `
      <div class="flex justify-between items-center mb-3">
        <h4 class="font-medium">Participant ${index + 1}</h4>
        ${index > 0 ? `<button type="button" onclick="this.parentElement.parentElement.remove()" class="text-red-500 text-sm hover:underline">Remove</button>` : ''}
      </div>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <input type="text" name="name_${index}" placeholder="Full Name" class="p-2 border rounded" required>
        <input type="email" name="email_${index}" placeholder="Email Address" class="p-2 border rounded" required>
        <select name="role_${index}" class="p-2 border rounded" required>
          <option value="">Select Role</option>
          <option value="Enterprise Architect">Enterprise Architect</option>
          <option value="Solution Architect">Solution Architect</option>
          <option value="IT Manager">IT Manager</option>
          <option value="CTO/CIO">CTO/CIO</option>
          <option value="Consultant">Consultant</option>
          <option value="Project Manager">Project Manager</option>
          <option value="Business Analyst">Business Analyst</option>
          <option value="Developer">Developer</option>
          <option value="Other">Other</option>
        </select>
      </div>
    `;
    container.appendChild(div);
  };

  /* Handle setup form submission */
  async function handleSetup(e) {
    e.preventDefault();

    const company = document.getElementById('company').value;
    const participantDivs = document.getElementById('participantsList').children;
    const participants = [];

    for (let i = 0; i < participantDivs.length; i++) {
      const name = document.querySelector(`input[name="name_${i}"]`).value;
      const email = document.querySelector(`input[name="email_${i}"]`).value;
      const role = document.querySelector(`select[name="role_${i}"]`).value;
      participants.push({ name, email, role });
    }

    currentSession = {
      company,
      participants,
      timestamp: new Date().toISOString()
    };

    currentUser = {
      name: participants[0].name || 'Assessment Lead',
      company: company,
      email: participants[0].email || 'lead@' + company.toLowerCase().replace(/\s/g, '') + '.com',
      role: participants[0].role || 'Assessment Coordinator'
    };

    showLoading('Preparing your assessment...');
    // Jump directly into the questions (no separate target page)
    setTimeout(() => askQuestion(0, {}, {}), 600);
  }

  /* ============================================
     ASSESSMENT QUESTIONS WITH IN-QUESTION TARGET
  ============================================ */
  function askQuestion(questionIndex, answers, targets) {
    if (questionIndex >= domains.length) {
      showLoading('Analyzing your responses...');
      setTimeout(() => showResults(answers, targets), 800);
      return;
    }

    const domain = domains[questionIndex];
    const matrix = MATRIX[domain.ID];
    const progress = Math.round((questionIndex / domains.length) * 100);

    const selectedScore = answers[questionIndex];
    const selectedTarget = targets[domain.ID]; // undefined until set on this screen

    root.innerHTML = `
      <div class="min-h-screen bg-gray-50">
        <header class="sap-shell-header">
          <div class="flex items-center">
            <svg width="60" height="24" viewBox="0 0 60 24" class="mr-4">
              <path fill="white" d="M0 6h12v12H0V6zm15 0h12v12H15V6zm15 0h12v12H30V6zm15 0h12v12H45V6z"/>
            </svg>
            <h1 class="text-lg font-semibold">Assessment in Progress</h1>
          </div>
          <div class="text-sm opacity-75">
            ${currentSession.company} | Question ${questionIndex + 1} of ${domains.length}
          </div>
        </header>

        <main class="p-6 max-w-4xl mx-auto">
          <div class="sap-tile p-8">
            <!-- Progress Bar -->
            <div class="mb-6">
              <div class="flex justify-between text-sm text-gray-600 mb-2">
                <span>Progress</span>
                <span>${progress}%</span>
              </div>
              <div class="sap-progress">
                <div class="sap-progress-fill" style="width: ${progress}%"></div>
              </div>
            </div>

            <!-- Domain Header -->
            <div class="mb-6">
              <h2 class="text-xl font-semibold text-gray-800 mb-2">${domain.name}</h2>
              <p class="text-lg text-gray-700 mb-4">${matrix.question}</p>

              <!-- Desired Target (Required) -->
              <div class="mb-4 p-4 rounded border border-blue-200 bg-blue-50">
                <label class="block text-sm font-medium text-blue-800 mb-2">Desired target for this domain (required)</label>
                <div class="flex items-center gap-3">
                  <select id="targetSelect" class="sap-input w-28">
                    <option value="">Select…</option>
                    ${[0,1,2,3,4,5].map(v => `
                      <option value="${v}" ${selectedTarget === v ? 'selected' : ''}>${v}</option>
                    `).join('')}
                  </select>
                  <span class="text-xs text-blue-800 opacity-80">Choose the maturity you aim to reach for <strong>${domain.name}</strong>.</span>
                </div>
              </div>

              <!-- Help / Guidance -->
              <details class="mb-4 rounded border border-gray-200 bg-white p-4">
                <summary class="cursor-pointer font-medium">💡 Need help deciding? (context & examples)</summary>
                <div class="mt-3 text-sm text-gray-700">
                  <p class="mb-2"><strong>How to choose an answer:</strong> Pick the line below that best describes your current state today.</p>
                  <ul class="list-disc ml-5 mb-3">
                    ${(GUIDANCE[domain.ID] || []).map(item => `<li>${item}</li>`).join('')}
                  </ul>
                  <p class="mb-2"><strong>What the scores usually look like:</strong></p>
                  <ul class="list-disc ml-5">
                    <li><strong>0–1</strong>: Ad-hoc, inconsistent, person-dependent.</li>
                    <li><strong>2–3</strong>: Defined, repeatable, tracked with some governance.</li>
                    <li><strong>4–5</strong>: Optimized at scale, measured outcomes, continuous improvement.</li>
                  </ul>
                </div>
              </details>

              <div class="text-sm text-gray-600">Select the option that best describes your current state:</div>
            </div>

            <!-- Answer Options with Visual Feedback -->
            <div class="space-y-3 mb-8">
              ${matrix.expl.map((explanation, score) => `
                <div class="option-card" data-score="${score}" 
                     style="border: 2px solid ${selectedScore === score ? '#0a6ed1' : '#e5e5e5'};
                            background: ${selectedScore === score ? '#f0f7ff' : 'white'};
                            cursor: pointer; padding: 16px; border-radius: 8px;
                            transition: all 0.2s ease;">
                  <div class="flex items-start">
                    <div class="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold mr-4"
                         style="background: ${selectedScore === score ? '#0a6ed1' : '#e8f4fd'}; 
                                color: ${selectedScore === score ? 'white' : '#0a6ed1'};">
                      ${score}
                    </div>
                    <div class="flex-1">
                      <p class="text-gray-800">${explanation}</p>
                    </div>
                    <div class="flex-shrink-0 ml-4">
                      <div class="w-5 h-5 border-2 rounded-full flex items-center justify-center"
                           style="border-color: ${selectedScore === score ? '#0a6ed1' : '#d1d5db'}; 
                                  background: ${selectedScore === score ? '#0a6ed1' : 'white'};">
                        ${selectedScore === score ? '<div class="w-2 h-2 bg-white rounded-full"></div>' : ''}
                      </div>
                    </div>
                  </div>
                </div>
              `).join('')}
            </div>

            <!-- Navigation -->
            <div class="flex justify-between">
              <button id="prevButton" ${questionIndex === 0 ? 'disabled' : ''} 
                      class="sap-button sap-button-secondary ${questionIndex === 0 ? 'opacity-50 cursor-not-allowed' : ''}">
                ← Previous
              </button>
              <button id="nextButton" class="sap-button ${(!isReadyToProceed(selectedScore, selectedTarget)) ? 'opacity-50 cursor-not-allowed' : ''}" 
                      ${!isReadyToProceed(selectedScore, selectedTarget) ? 'disabled' : ''}>
                ${questionIndex === domains.length - 1 ? 'Complete Assessment' : 'Next →'}
              </button>
            </div>
          </div>
        </main>
      </div>
    `;

    // Wire up target selection
    const targetSelect = document.getElementById('targetSelect');
    targetSelect.addEventListener('change', () => {
      const val = targetSelect.value === '' ? undefined : parseInt(targetSelect.value);
      targets[domain.ID] = val;
      updateNextButtonState();
    });

    // Wire up answer selection
    document.querySelectorAll('.option-card').forEach(card => {
      card.addEventListener('click', (e) => {
        e.preventDefault();
        const score = parseInt(card.dataset.score);
        answers[questionIndex] = score;

        // Update visuals
        document.querySelectorAll('.option-card').forEach(c => {
          const isSelected = parseInt(c.dataset.score) === score;
          c.style.border = `2px solid ${isSelected ? '#0a6ed1' : '#e5e5e5'}`;
          c.style.background = isSelected ? '#f0f7ff' : 'white';

          const scoreCircle = c.querySelector('.flex-shrink-0.w-8');
          if (scoreCircle) {
            scoreCircle.style.background = isSelected ? '#0a6ed1' : '#e8f4fd';
            scoreCircle.style.color = isSelected ? 'white' : '#0a6ed1';
          }

          const radio = c.querySelector('.w-5.h-5');
          if (radio) {
            radio.style.borderColor = isSelected ? '#0a6ed1' : '#d1d5db';
            radio.style.background = isSelected ? '#0a6ed1' : 'white';
            radio.innerHTML = isSelected ? '<div class="w-2 h-2 bg-white rounded-full"></div>' : '';
          }
        });

        updateNextButtonState();
      });
    });

    function isReadyToProceed(score, target) {
      return score !== undefined && target !== undefined;
    }

    function updateNextButtonState() {
      const nextBtn = document.getElementById('nextButton');
      const score = answers[questionIndex];
      const target = targets[domain.ID];
      const ready = isReadyToProceed(score, target);
      nextBtn.disabled = !ready;
      nextBtn.className = `sap-button ${ready ? '' : 'opacity-50 cursor-not-allowed'}`;
    }

    // Navigation
    document.getElementById('prevButton')?.addEventListener('click', () => {
      if (questionIndex > 0) askQuestion(questionIndex - 1, answers, targets);
    });

    document.getElementById('nextButton')?.addEventListener('click', () => {
      // Persist the chosen target into the domains list as well (so results use it)
      const chosen = targets[domain.ID];
      const domainRef = domains.find(d => d.ID === domain.ID);
      domainRef.target = chosen ?? 0;

      if (isReadyToProceed(answers[questionIndex], chosen)) {
        askQuestion(questionIndex + 1, answers, targets);
      }
    });
  }

  /* ============================================
     RESULTS DISPLAY
  ============================================ */
  async function showResults(answers, targets) {
    // Ensure every domain has a target set (defensive fallback to 0)
    domains.forEach(d => {
      if (typeof d.target !== 'number') d.target = (targets[d.ID] ?? 0);
    });

    const results = domains.map((domain, index) => ({
      id: domain.ID,
      name: domain.name,
      score: answers[index] ?? 0,
      target: domain.target,
      weight: domain.weight,
      gap: domain.target - (answers[index] ?? 0),
      priority: getPriorityLevel(domain.target - (answers[index] ?? 0))
    }));

    const overallAverage = (results.reduce((sum, r) => sum + r.score, 0) / results.length).toFixed(1);
    const weightedAverage = (results.reduce((sum, r) => sum + r.score * r.weight, 0) /
                            results.reduce((sum, r) => sum + r.weight, 0)).toFixed(1);
    const criticalGaps = results.filter(r => r.gap > 1).length;
    const highPriorityItems = results.filter(r => r.priority === 'high').length;

    // Save session per participant
    for (const participant of currentSession.participants) {
      await saveSession({
        company: currentSession.company,
        participantName: participant.name,
        participantEmail: participant.email,
        participantRole: participant.role,
        results: results,
        overallAverage: overallAverage,
        weightedAverage: weightedAverage,
        criticalGaps: criticalGaps,
        timestamp: new Date().toISOString()
      });
    }

    root.innerHTML = `
      <div class="min-h-screen bg-gray-50">
        <!-- Header -->
        <header class="sap-shell-header">
          <div class="flex items-center">
            <svg width="60" height="24" viewBox="0 0 60 24" class="mr-4">
              <path fill="white" d="M0 6h12v12H0V6zm15 0h12v12H15V6zm15 0h12v12H30V6zm15 0h12v12H45V6z"/>
            </svg>
            <h1 class="text-lg font-semibold">Assessment Results</h1>
          </div>
          <div class="flex gap-4">
            <button onclick="downloadCSV()" class="text-white hover:bg-white hover:bg-opacity-10 px-3 py-2 rounded">
              📥 Export CSV
            </button>
            <button onclick="downloadSQL()" class="text-white hover:bg-white hover:bg-opacity-10 px-3 py-2 rounded">
              📥 Export SQL
            </button>
            <div class="text-sm opacity-75">${currentSession.company}</div>
          </div>
        </header>

        <main class="p-6 max-w-6xl mx-auto">
          <div class="sap-tile p-6 mb-6 animate-fade-in">
            <div class="text-center">
              <h2 class="text-2xl font-bold text-gray-800 mb-2">Assessment Complete</h2>
              <p class="text-gray-600">Your Enterprise Architecture maturity assessment results</p>
            </div>
          </div>

          <div class="sap-tile p-4 mb-6">
            <h3 class="font-semibold mb-2">Assessment Participants</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
              ${currentSession.participants.map(p => `
                <div class="flex items-center">
                  <span class="w-2 h-2 bg-sapblue rounded-full mr-2"></span>
                  ${p.name} (${p.role})
                </div>
              `).join('')}
            </div>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <div class="sap-tile p-6 text-center">
              <div class="text-3xl font-bold text-sapblue mb-2">${overallAverage}</div>
              <div class="text-sm text-gray-600">Overall Average</div>
              <div class="text-xs text-gray-500 mt-1">Out of 5.0</div>
            </div>
            <div class="sap-tile p-6 text-center">
              <div class="text-3xl font-bold text-sapblue mb-2">${weightedAverage}</div>
              <div class="text-sm text-gray-600">Weighted Score</div>
              <div class="text-xs text-gray-500 mt-1">Adjusted for importance</div>
            </div>
            <div class="sap-tile p-6 text-center">
              <div class="text-3xl font-bold ${criticalGaps > 0 ? 'text-red-600' : 'text-green-600'} mb-2">${criticalGaps}</div>
              <div class="text-sm text-gray-600">Critical Gaps</div>
              <div class="text-xs text-gray-500 mt-1">Domains requiring attention</div>
            </div>
            <div class="sap-tile p-6 text-center">
              <div class="text-3xl font-bold ${overallAverage >= BENCHMARKS.industry.avg ? 'text-green-600' : 'text-yellow-600'} mb-2">
                ${overallAverage >= BENCHMARKS.industry.avg ? '✓' : '△'}
              </div>
              <div class="text-sm text-gray-600">vs Industry</div>
              <div class="text-xs text-gray-500 mt-1">${overallAverage >= BENCHMARKS.industry.avg ? 'Above' : 'Below'} average (${BENCHMARKS.industry.avg})</div>
            </div>
          </div>

          <div class="sap-tile mb-6">
            <div class="flex border-b border-gray-200">
              <button class="sap-tab-header active" onclick="switchTab('overview')">Overview</button>
              <button class="sap-tab-header" onclick="switchTab('detailed')">Detailed Analysis</button>
              <button class="sap-tab-header" onclick="switchTab('recommendations')">Recommendations</button>
              <button class="sap-tab-header" onclick="switchTab('roadmap')">Roadmap</button>
            </div>

            <div id="overview-tab" class="sap-tab-content active">
              <div class="p-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <h3 class="font-semibold mb-4">Maturity Radar</h3>
                    <canvas id="radarChart" width="400" height="400"></canvas>
                  </div>
                  <div>
                    <h3 class="font-semibold mb-4">Domain Summary</h3>
                    <div class="space-y-4">
                      ${results.map(r => `
                        <div class="flex items-center justify-between p-3 rounded-lg ${
                          r.gap <= 0 ? 'bg-green-50 border border-green-200' :
                          r.gap <= 1 ? 'bg-yellow-50 border border-yellow-200' :
                          'bg-red-50 border border-red-200'
                        }">
                          <div class="flex-1">
                            <div class="font-medium text-gray-800">${r.name}</div>
                            <div class="text-sm text-gray-600">Score: ${r.score}/5 | Target: ${r.target}/5</div>
                          </div>
                          <div class="text-right">
                            <div class="font-bold ${
                              r.gap <= 0 ? 'text-green-600' :
                              r.gap <= 1 ? 'text-yellow-600' :
                              'text-red-600'
                            }">
                              ${r.gap <= 0 ? '✓ On Target' : `Gap: ${r.gap.toFixed(1)}`}
                            </div>
                            <div class="text-xs capitalize font-medium ${
                              r.priority === 'high' ? 'text-red-600' :
                              r.priority === 'medium' ? 'text-yellow-600' :
                              'text-green-600'
                            }">
                              ${r.priority} Priority
                            </div>
                          </div>
                        </div>
                      `).join('')}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div id="detailed-tab" class="sap-tab-content">
              <div class="p-6 space-y-6">
                <h3 class="font-semibold">Domain-by-Domain Analysis</h3>
                ${results.map(r => `
                  <div class="border border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between items-start mb-3">
                      <div>
                        <h4 class="font-semibold text-gray-800">${r.name}</h4>
                        <p class="text-sm text-gray-600">${MATRIX[r.id].question}</p>
                      </div>
                      <div class="text-right">
                        <div class="text-2xl font-bold text-sapblue">${r.score}/5</div>
                        <div class="text-xs">Target: ${r.target}/5</div>
                      </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h5 class="font-medium mb-2">Current State</h5>
                        <p class="text-sm mb-3">${MATRIX[r.id].expl[r.score]}</p>

                        <h5 class="font-medium mb-2">Performance vs Benchmark</h5>
                        <div class="flex items-center mb-2">
                          <span class="text-sm w-20">Your Score:</span>
                          <div class="flex-1 bg-gray-200 rounded h-2 mx-2">
                            <div class="bg-sapblue h-2 rounded" style="width: ${(r.score/5)*100}%"></div>
                          </div>
                          <span class="text-sm">${r.score}/5</span>
                        </div>
                        <div class="flex items-center">
                          <span class="text-sm w-20">Industry:</span>
                          <div class="flex-1 bg-gray-200 rounded h-2 mx-2">
                            <div class="bg-gray-400 h-2 rounded" style="width: ${(BENCHMARKS.industry.avg/5)*100}%"></div>
                          </div>
                          <span class="text-sm">${BENCHMARKS.industry.avg}/5</span>
                        </div>
                      </div>

                      <div>
                        <h5 class="font-medium mb-2">Gap Analysis</h5>
                        <div class="space-y-2">
                          <div class="flex justify-between">
                            <span class="text-sm">Gap Size:</span>
                            <span class="font-semibold ${r.gap<=0?'text-green-600':r.gap<2?'text-yellow-600':'text-red-600'}">${r.gap.toFixed(1)}</span>
                          </div>
                          <div class="flex justify-between">
                            <span class="text-sm">Priority:</span>
                            <span class="font-semibold capitalize ${r.priority==='high'?'text-red-600':r.priority==='medium'?'text-yellow-600':'text-green-600'}">${r.priority}</span>
                          </div>
                          <div class="flex justify-between">
                            <span class="text-sm">Improvement Time:</span>
                            <span class="font-semibold">${r.gap >= 3 ? '12-18 months' : r.gap >= 2 ? '6-12 months' : r.gap >= 1 ? '3-6 months' : 'Maintain'}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>

            <div id="recommendations-tab" class="sap-tab-content">
              <div class="p-6 space-y-6">
                <h3 class="font-semibold">Actionable Recommendations</h3>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 class="font-semibold mb-3 text-red-600">High Priority Actions</h4>
                    <div class="space-y-3">
                      ${results.filter(r=>r.priority==='high').map(r=>`
                        <div class="border-l-4 border-red-500 bg-red-50 p-3 rounded">
                          <h5 class="font-medium">${r.name}</h5>
                          <p class="text-sm mt-1">${MATRIX[r.id].recommendations[r.score]}</p>
                          <div class="text-xs mt-2 text-gray-600">Gap: ${r.gap.toFixed(1)} | Immediate action required</div>
                        </div>
                      `).join('')}
                      ${results.filter(r=>r.priority==='high').length === 0 ? '<div class="text-sm text-gray-500">No critical actions required</div>' : ''}
                    </div>
                  </div>

                  <div>
                    <h4 class="font-semibold mb-3 text-yellow-600">Medium Priority Actions</h4>
                    <div class="space-y-3">
                      ${results.filter(r=>r.priority==='medium').map(r=>`
                        <div class="border-l-4 border-yellow-500 bg-yellow-50 p-3 rounded">
                          <h5 class="font-medium">${r.name}</h5>
                          <p class="text-sm mt-1">${MATRIX[r.id].recommendations[r.score]}</p>
                          <div class="text-xs mt-2 text-gray-600">Gap: ${r.gap.toFixed(1)} | Plan for improvement</div>
                        </div>
                      `).join('')}
                      ${results.filter(r=>r.priority==='medium').length === 0 ? '<div class="text-sm text-gray-500">No medium priority actions</div>' : ''}
                    </div>
                  </div>
                </div>

                <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 class="font-semibold mb-3 text-blue-800">Strategic Recommendations</h4>
                  <div class="space-y-2 text-sm">
                    ${highPriorityItems > 2 ? '<div>• Establish dedicated EA transformation program with clear governance and timeline</div>' : ''}
                    ${criticalGaps > 0 ? '<div>• Focus on critical domains first as they have highest impact on EA success</div>' : ''}
                    ${overallAverage < BENCHMARKS.industry.avg ? '<div>• Invest in foundational capabilities to reach industry standards</div>' : '<div>• Leverage above-average performance for competitive differentiation</div>'}
                    <div>• Regular assessment every 6-12 months to track progress</div>
                  </div>
                </div>
              </div>
            </div>

            <div id="roadmap-tab" class="sap-tab-content">
              <div class="p-6 space-y-6">
                <h3 class="font-semibold">Implementation Roadmap</h3>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <h4 class="font-semibold mb-3 text-red-600">Phase 1: Foundation (0-6 months)</h4>
                    <div class="space-y-3">
                      ${results.filter(r=>r.priority==='high' || (r.score <= 1 && r.gap > 0)).map(r=>`
                        <div class="sap-timeline-item">
                          <h5 class="font-medium">${r.name}</h5>
                          <p class="text-sm text-gray-600">Current: ${r.score}/5 → Target: ${Math.min(r.score + 2, r.target)}/5</p>
                          <p class="text-xs mt-1">${MATRIX[r.id].recommendations[r.score]}</p>
                        </div>
                      `).join('')}
                    </div>
                  </div>

                  <div>
                    <h4 class="font-semibold mb-3 text-yellow-600">Phase 2: Enhancement (6-12 months)</h4>
                    <div class="space-y-3">
                      ${results.filter(r=>r.priority==='medium' && r.score > 1).map(r=>`
                        <div class="sap-timeline-item">
                          <h5 class="font-medium">${r.name}</h5>
                          <p class="text-sm text-gray-600">Current: ${r.score}/5 → Target: ${Math.min(r.score + 1, r.target)}/5</p>
                          <p class="text-xs mt-1">${MATRIX[r.id].recommendations[Math.min(r.score + 1, 5)]}</p>
                        </div>
                      `).join('')}
                    </div>
                  </div>

                  <div>
                    <h4 class="font-semibold mb-3 text-green-600">Phase 3: Optimization (12+ months)</h4>
                    <div class="space-y-3">
                      ${results.filter(r=>r.priority==='low' || r.gap <= 0).map(r=>`
                        <div class="sap-timeline-item">
                          <h5 class="font-medium">${r.name}</h5>
                          <p class="text-sm text-gray-600">${r.gap <= 0 ? 'Maintain excellence' : `Current: ${r.score}/5 → Target: ${r.target}/5`}</p>
                          <p class="text-xs mt-1">${r.gap <= 0 ? 'Continue best practices and innovation' : MATRIX[r.id].recommendations[r.score]}</p>
                        </div>
                      `).join('')}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="flex flex-wrap gap-4 justify-center">
            <button onclick="location.reload()" class="sap-button sap-button-secondary">
              🔄 New Assessment
            </button>
          </div>
        </main>
      </div>
    `;

    // Radar chart
    setTimeout(() => {
      const ctx = document.getElementById('radarChart');
      if (ctx) {
        new Chart(ctx, {
          type: 'radar',
          data: {
            labels: results.map(r => r.name.split(' ').slice(0, 2).join(' ')),
            datasets: [
              {
                label: 'Current Score',
                data: results.map(r => r.score),
                backgroundColor: 'rgba(10, 110, 209, 0.2)',
                borderColor: '#0a6ed1',
                borderWidth: 2,
                pointBackgroundColor: '#0a6ed1',
                pointBorderColor: '#0a6ed1',
                pointRadius: 4
              },
              {
                label: 'Target',
                data: results.map(r => r.target),
                backgroundColor: 'rgba(34, 197, 94, 0.1)',
                borderColor: '#22c55e',
                borderWidth: 2,
                borderDash: [5, 5],
                pointBackgroundColor: '#22c55e',
                pointBorderColor: '#22c55e',
                pointRadius: 3
              },
              {
                label: 'Industry Average',
                data: results.map(() => BENCHMARKS.industry.avg),
                backgroundColor: 'transparent',
                borderColor: '#f59e0b',
                borderWidth: 1,
                borderDash: [2, 2],
                pointBackgroundColor: '#f59e0b',
                pointBorderColor: '#f59e0b',
                pointRadius: 2
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: true,
            aspectRatio: 1,
            scales: {
              r: {
                min: 0,
                max: 5,
                ticks: { stepSize: 1, backdropColor: 'transparent' },
                grid: { color: '#e5e5e5' },
                angleLines: { color: '#e5e5e5' }
              }
            },
            plugins: {
              legend: {
                position: 'bottom',
                labels: { padding: 20, usePointStyle: true }
              }
            }
          }
        });
      }
    }, 100);

    // Tabs
    window.switchTab = (tabName) => {
      document.querySelectorAll('.sap-tab-header').forEach(tab => tab.classList.remove('active'));
      document.querySelectorAll('.sap-tab-content').forEach(content => content.classList.remove('active'));
      event.target.classList.add('active');
      document.getElementById(tabName + '-tab').classList.add('active');
    };
  }

  /* ============================================
     EXPORT FUNCTIONS
  ============================================ */
  window.downloadCSV = async () => {
    const csv = await exportToCSV();
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `assessment_${currentSession.company.replace(/\s/g, '_')}_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  window.downloadSQL = async () => {
    const sql = await exportToSQL();
    const blob = new Blob([sql], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `assessment_${currentSession.company.replace(/\s/g, '_')}_${new Date().toISOString().split('T')[0]}.sql`;
    a.click();
  };

  /* ============================================
     INITIALIZE APPLICATION
  ============================================ */
  await initDB();
  renderCompanySetup();
})();
